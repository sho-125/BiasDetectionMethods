
# User-facing function -----------------------------------------------------

#' Run publication-bias methods for a meta-analysis
#'
#' @param yi Numeric vector of observed effect sizes.
#' @param sei Numeric vector of standard errors associated with \code{yi}.
#' @param obs Optional numeric vector of study-level sample size proxies. This is
#'   required for the EGGER4 / EGGER5 implementations in this package.
#' @param study_id Optional study identifiers. Defaults to 1:n.
#' @param alpha Two-sided significance level used by the caliper windows and TES.
#'   TES uses \code{alpha / 2} for its right-tail threshold, matching the supplied
#'   simulation code. The default caliper boundaries reproduce that code's fixed
#'   intervals around 1.96. PSST/TESS retain their paper-defined 0.05 thresholds.
#' @param sort_by_rank Logical. If \code{TRUE}, sort the displayed publication-bias
#'   results by the selected ranking metric for the detected paper case.
#' @param ranking_metric Character. Ranking metric used to sort the displayed
#'   publication-bias results when \code{sort_by_rank = TRUE}. Use
#'   \code{"logit_distance"} (default) or \code{"balanced_accuracy"}.
#'   Short aliases \code{"ldist"} and \code{"ba"} are also accepted.
#'
#' @return An object of class \code{pbias_result} with elements:
#'   \itemize{
#'     \item \code{bias_summary}: one row per paper method, with publication-bias p-values.
#'     \item \code{publication_table}: formatted display table of publication-bias tests.
#'     \item \code{decision_rule}: practical decision-rule recommendation used to mark methods with \code{***}.
#'     \item \code{case}: the paper case based on number of studies and I-squared.
#'     \item \code{interpretation}: short interpretation text for the publication-bias tests.
#'     \item \code{meta}: run metadata.
#'   }
#'
#' @examples
#' yi <- c(0.20, 0.35, 0.10, 0.42, 0.30, 0.28)
#' sei <- c(0.10, 0.12, 0.15, 0.11, 0.09, 0.13)
#' out <- pbias_table(yi, sei)
#' print(out)
#'
#' @export
pbias_table <- function(yi, sei, obs = NULL, study_id = NULL, alpha = 0.05,
                        sort_by_rank = TRUE,
                        ranking_metric = c("logit_distance", "balanced_accuracy")) {
  ranking_metric <- .match_ranking_metric(ranking_metric)
  .validate_inputs(yi, sei, obs, study_id, alpha, sort_by_rank, ranking_metric)
  
  n <- length(yi)
  if (is.null(study_id)) {
    study_id <- seq_len(n)
  }
  
  dt <- data.frame(
    eff = as.numeric(yi),
    se = as.numeric(sei),
    StdID = as.numeric(study_id),
    stringsAsFactors = FALSE
  )
  if (!is.null(obs)) {
    dt$obs <- as.numeric(obs)
  }
  
  # Metadata and mappings
  method_map <- .method_map()
  bias_rows <- vector("list", nrow(method_map))
  names(bias_rows) <- method_map$paper_method
  
  # Helper for summary rows
  add_bias <- function(code_method, p_value, status = "ok", note = "") {
    if (length(p_value) != 1L || !is.finite(p_value) || p_value < 0 || p_value > 1) {
      p_value <- NA_real_
      if (identical(status, "ok")) {
        status <- "failed"
        note <- "The method did not return a finite p-value between zero and one."
      }
    }
    idx <- match(code_method, method_map$code_method)
    meta_row <- method_map[idx, , drop = FALSE]
    bias_rows[[meta_row$paper_method]] <<- data.frame(
      paper_method = meta_row$paper_method,
      code_method = meta_row$code_method,
      category = meta_row$category,
      publication_bias_p = as.numeric(p_value),
      status = status,
      note = note,
      stringsAsFactors = FALSE
    )
    invisible(NULL)
  }
  
  # Baseline random-effects model (not counted among the 21 paper methods)
  baseline <- .fit_baseline_re(dt)
  case_info <- .classify_meta_case(n, baseline$model)
  performance_rank <- .type1_performance_table(case_info$code)
  
  # EGGER1 - FE
  res <- .fit_egger_fe(dt)
  add_bias("FE", res$pub_bias_p, res$status, res$note)
  
  # EGGER2 - RE
  res <- .fit_egger_re(dt)
  add_bias("RE", res$pub_bias_p, res$status, res$note)
  
  # EGGER3 - WLS
  res <- .fit_egger_wls(dt)
  add_bias("WLS", res$pub_bias_p, res$status, res$note)
  
  # EGGER4 - MAIVE
  res <- .fit_maive(dt)
  add_bias("MAIVE", res$pub_bias_p, res$status, res$note)
  
  # EGGER5 - FATIV
  res <- .fit_fativ(dt)
  add_bias("FATIV", res$pub_bias_p, res$status, res$note)
  
  # Selection models
  res <- .fit_psm3(dt)
  add_bias("3PSM", res$pub_bias_p, res$status, res$note)
  
  res <- .fit_psm4(dt)
  add_bias("4PSM", res$pub_bias_p, res$status, res$note)
  
  res <- .fit_ak1(dt)
  add_bias("AK1", res$pub_bias_p, res$status, res$note)
  
  res <- .fit_ak2(dt)
  add_bias("AK2", res$pub_bias_p, res$status, res$note)
  
  res <- .fit_puniform(dt)
  add_bias("Puniform", res$pub_bias_p, res$status, res$note)
  
  # Other SE-based methods
  res <- .fit_ek(dt)
  add_bias("EK", res$pub_bias_p, res$status, res$note)
  
  res <- .fit_begg(dt)
  add_bias("Begg", res$pub_bias_p, res$status, res$note)
  
  res <- .fit_skew(dt, baseline$model)
  add_bias("SKEWNESS", res$skew_p, res$status, res$note)
  add_bias("SKEWCombined", res$combined_p, res$status, res$note)
  
  # Excess significance tests
  res <- .fit_tes(dt, alpha = alpha / 2)
  add_bias("TES", res$pub_bias_p, res$status, res$note)
  
  res <- .fit_psst_tess(dt)
  add_bias("PSST", res$psst_p, res$status, res$note)
  add_bias("TESS", res$tess_p, res$status, res$note)
  
  # Caliper tests
  res <- .fit_calipers(dt, alpha = alpha)
  for (i in seq_len(nrow(res$summary))) {
    add_bias(res$summary$code_method[i], res$summary$publication_bias_p[i],
             res$summary$status[i], res$summary$note[i])
  }
  
  # Fill any missing summary rows with NA
  for (i in seq_len(nrow(method_map))) {
    if (is.null(bias_rows[[method_map$paper_method[i]]])) {
      add_bias(method_map$code_method[i], NA_real_, "not_run", "No result returned.")
    }
  }
  
  bias_summary <- do.call(rbind, bias_rows)
  row.names(bias_summary) <- NULL
  decision_rule <- .practical_decision_rule(case_info, bias_summary)
  
  out <- list(
    bias_summary = .make_bias_summary(bias_summary),
    publication_table = .make_publication_table(
      bias_summary,
      performance_rank = performance_rank,
      sort_by_rank = sort_by_rank,
      ranking_metric = ranking_metric,
      decision_rule = decision_rule
    ),
    decision_rule = decision_rule,
    case = case_info,
    interpretation = paste(
      "Null hypothesis: no publication bias.",
      "Rejection indicates that the method detects the existence of publication bias."
    ),
    meta = list(
      n_studies = n,
      has_obs = !is.null(obs),
      alpha = alpha,
      sort_by_rank = sort_by_rank,
      ranking_metric = ranking_metric,
      ranking_metric_label = .ranking_metric_label(ranking_metric),
      performance_source = "Performance tables from the publication bias paper",
      recommendation_marker = "***",
      timestamp = Sys.time()
    )
  )
  class(out) <- "pbias_result"
  out
}

#' @export
print.pbias_result <- function(x, digits = 3, ...) {
  cat("\n")
  cat("Bias Test Results\n")
  cat("=============================\n")
  ranking_metric <- if (!is.null(x$meta$ranking_metric)) {
    x$meta$ranking_metric
  } else {
    "logit_distance"
  }
  ranking_label <- .ranking_metric_label(ranking_metric)
  cat(paste0(
    "Caution: These recommendations are derived from simulated meta-analyses based on the experimental conditions in Carter et al. (2019). ",
    "Rankings reflect ", ranking_label, " in those simulations, not universal method performance, ",
    "and should be applied with care because bias-detection tests may behave differently in real meta-analytic applications.\n\n"
  ))
  cat("Null hypothesis: no bias\n")
  cat("\n")
  cat("Studies       : ", x$meta$n_studies, "\n", sep = "")
  cat("I-squared     : ", .format_num(x$case$i2, digits), "\n", sep = "")
  cat("obs supplied  : ", if (isTRUE(x$meta$has_obs)) "yes" else "no", "\n", sep = "")
  if (!is.null(x$case)) {
    cat("Paper case    : ", .format_case_value(x$case, digits = digits), "\n", sep = "")
  }
  if (!is.null(x$decision_rule)) {
    cat("Decision rule : ", .format_decision_rule_value(x$decision_rule), "\n", sep = "")
  }
  cat("\n")
  ranking_title <- paste0("Ranked by ", ranking_label)
  cat(ranking_title, "\n", sep = "")
  cat(paste(rep("-", nchar(ranking_title)), collapse = ""), "\n", sep = "")
  .print_publication_table(x$publication_table)
  cat("\n")
  cat("-----\n")
  cat(paste(strwrap(.format_output_note(x), width = 78), collapse = "\n"), "\n")
  cat("\n")
  
  invisible(x)
}

# Internal maps and templates ---------------------------------------------

.method_map <- function() {
  data.frame(
    paper_method = c(
      "BEGG", "EGGER1", "EGGER2", "EGGER3", "EGGER4", "EGGER5",
      "EK", "SKEW1", "SKEW2", "PSM3", "PSM4", "AK1", "AK2", "PUNIF",
      "TES", "PSST", "TESS", "CALI05", "CALI10", "CALI15", "CALI20"
    ),
    code_method = c(
      "Begg", "FE", "RE", "WLS", "MAIVE", "FATIV",
      "EK", "SKEWNESS", "SKEWCombined", "3PSM", "4PSM", "AK1", "AK2", "Puniform",
      "TES", "PSST", "TESS", "Caliper05", "Caliper10", "Caliper15", "Caliper20"
    ),
    category = c(
      rep("standard_error_based", 9),
      rep("selection_model", 5),
      rep("excess_statistical_significance", 3),
      rep("caliper", 4)
    ),
    stringsAsFactors = FALSE
  )
}

.validate_inputs <- function(yi, sei, obs, study_id, alpha, sort_by_rank,
                             ranking_metric) {
  if (!is.numeric(yi) || !is.numeric(sei)) {
    stop("`yi` and `sei` must be numeric vectors.")
  }
  if (length(yi) != length(sei)) {
    stop("`yi` and `sei` must have the same length.")
  }
  if (length(yi) < 3L) {
    stop("At least 3 studies are required.")
  }
  if (any(!is.finite(yi)) || any(!is.finite(sei)) || any(sei <= 0)) {
    stop("`yi` must be finite and `sei` must be finite and strictly positive.")
  }
  if (!is.null(obs)) {
    if (!is.numeric(obs) || length(obs) != length(yi)) {
      stop("If supplied, `obs` must be a numeric vector of the same length as `yi`.")
    }
    if (any(!is.finite(obs) | obs <= 0)) {
      stop("If supplied, `obs` must be finite and strictly positive.")
    }
  }
  if (!is.null(study_id) && length(study_id) != length(yi)) {
    stop("If supplied, `study_id` must have the same length as `yi`.")
  }
  if (!is.numeric(alpha) || length(alpha) != 1L || !is.finite(alpha) || alpha <= 0 || alpha >= 1) {
    stop("`alpha` must be a single number between 0 and 1.")
  }
  if (!is.logical(sort_by_rank) || length(sort_by_rank) != 1L || is.na(sort_by_rank)) {
    stop("`sort_by_rank` must be TRUE or FALSE.")
  }
  if (!is.character(ranking_metric) || length(ranking_metric) != 1L ||
      !(ranking_metric %in% c("logit_distance", "balanced_accuracy"))) {
    stop("`ranking_metric` must be 'logit_distance' or 'balanced_accuracy'.")
  }
}

.na_result <- function(note = "", status = "failed") {
  list(
    estimates = NULL,
    pub_bias_p = NA_real_,
    status = status,
    note = note
  )
}

.make_estimates <- function(term, estimate = NA_real_, std_error = NA_real_,
                            statistic = NA_real_, p_value = NA_real_,
                            conf_low = NA_real_, conf_high = NA_real_,
                            note = "") {
  data.frame(
    term = term,
    estimate = as.numeric(estimate),
    std_error = as.numeric(std_error),
    statistic = as.numeric(statistic),
    p_value = as.numeric(p_value),
    conf_low = as.numeric(conf_low),
    conf_high = as.numeric(conf_high),
    note = as.character(note),
    stringsAsFactors = FALSE
  )
}

.format_num <- function(x, digits = 3) {
  ifelse(is.na(x), "", formatC(x, format = "f", digits = digits))
}

.format_result_p <- function(p, status, digits = 3) {
  if (identical(status, "ok") && !is.na(p)) return(.format_num(p, digits))
  if (identical(status, "requires_obs")) return("requires obs")
  if (identical(status, "not_applicable")) return("n/a")
  if (identical(status, "failed")) return("failed")
  if (identical(status, "not_run")) return("not run")
  if (!is.na(p)) return(.format_num(p, digits))
  ""
}

.match_ranking_metric <- function(ranking_metric) {
  if (length(ranking_metric) > 1L) {
    ranking_metric <- ranking_metric[1L]
  }
  if (!is.character(ranking_metric) || length(ranking_metric) != 1L ||
      is.na(ranking_metric)) {
    stop("`ranking_metric` must be 'logit_distance' or 'balanced_accuracy'.")
  }
  metric <- tolower(gsub("[ -]+", "_", ranking_metric))
  if (metric %in% c("logit_distance", "logit", "distance", "ldist")) {
    return("logit_distance")
  }
  if (metric %in% c("balanced_accuracy", "balanced", "ba")) {
    return("balanced_accuracy")
  }
  stop("`ranking_metric` must be 'logit_distance' or 'balanced_accuracy'.")
}

.ranking_metric_label <- function(ranking_metric) {
  metric <- .match_ranking_metric(ranking_metric)
  if (identical(metric, "balanced_accuracy")) {
    return("Balanced Accuracy")
  }
  "Logit Distance"
}

.format_output_note <- function(x) {
  case_code <- x$case$code
  
  case_text <- if (!is.null(case_code) && length(case_code) == 1 && !is.na(case_code)) {
    paste0("case ", case_code)
  } else {
    "the detected paper case"
  }
  
  ranking_metric <- if (!is.null(x$meta$ranking_metric)) {
    x$meta$ranking_metric
  } else {
    "logit_distance"
  }
  ranking_label <- .ranking_metric_label(ranking_metric)
  ranking_hint <- if (identical(ranking_metric, "balanced_accuracy")) {
    "Use ranking_metric = \"logit_distance\" to sort by Logit Distance instead."
  } else {
    "Use ranking_metric = \"balanced_accuracy\" to sort by Balanced Accuracy instead."
  }
  
  paste(
    "* Some tests were excluded from the rankings because the data conditions did not satisfy their applicability requirements or because they exhibited substantial convergence problems.\n",
    "Note: The estimated p-value is calculated from the user's data.",
    paste0(
      "Balanced Accuracy and Logit Distance are based on the results from OUR BIAS paper for ",
      case_text,
      "."
    ),
    paste0("Rows are sorted by ", ranking_label, " when sort_by_rank = TRUE."),
    ranking_hint,
    "A small p-value indicates evidence of bias.",
    if (!is.null(x$decision_rule) && length(x$decision_rule$marked_methods) > 0) {
      "*** marks the method recommended by the practical decision rule for the observed setting."
    } else {
      ""
    },
    sep = "\n"
  )
}

.print_publication_table <- function(tab) {
  if (is.null(tab) || nrow(tab) == 0) {
    cat("(no publication-bias results)\n")
    return(invisible(NULL))
  }
  
  work <- as.data.frame(tab, stringsAsFactors = FALSE, check.names = FALSE)
  for (nm in names(work)) {
    work[[nm]] <- as.character(work[[nm]])
    work[[nm]][is.na(work[[nm]])] <- ""
  }
  
  widths <- vapply(seq_along(work), function(i) {
    max(nchar(c(names(work)[i], work[[i]]), type = "width"))
  }, integer(1))
  
  header <- paste(mapply(function(value, width) {
    format(value, width = width, justify = "left")
  }, names(work), widths, USE.NAMES = FALSE), collapse = "  ")
  rule <- paste(vapply(widths, function(w) paste(rep("-", w), collapse = ""),
                       character(1)), collapse = "  ")
  cat(header, "\n", sep = "")
  cat(rule, "\n", sep = "")
  
  for (i in seq_len(nrow(work))) {
    row_values <- unlist(work[i, ], use.names = FALSE)
    row <- paste(mapply(function(value, width) {
      format(value, width = width, justify = "left")
    }, row_values, widths, USE.NAMES = FALSE), collapse = "  ")
    cat(row, "\n", sep = "")
  }
  
  invisible(NULL)
}

.classify_meta_case <- function(n, model) {
  i2 <- NA_real_
  if (!is.null(model) &&
      !is.null(model$I2) &&
      length(model$I2) == 1L &&
      is.finite(model$I2)) {
    i2 <- max(0, as.numeric(model$I2) / 100)
  }
  
  if (n <= 10L) {
    size_code <- "S"
    size_category <- "Small"
    size_rule <- "K <= 10"
  } else if (n <= 100L) {
    size_code <- "M"
    size_category <- "Medium"
    size_rule <- "10 < K <= 100"
  } else {
    size_code <- "L"
    size_category <- "Large"
    size_rule <- "K > 100"
  }
  
  if (!is.finite(i2)) {
    heterogeneity_code <- NA_character_
    heterogeneity_category <- "Unknown"
    heterogeneity_rule <- "I2 unavailable"
    code <- NA_character_
    note <- "Random-effects model failed; I2-based paper case could not be assigned."
  } else if (i2 < 0.29) {
    heterogeneity_code <- "S"
    heterogeneity_category <- "Small"
    heterogeneity_rule <- "I2 < 0.29"
    code <- paste0(size_code, heterogeneity_code)
    note <- ""
  } else if (i2 < 0.60) {
    heterogeneity_code <- "M"
    heterogeneity_category <- "Medium"
    heterogeneity_rule <- "0.29 <= I2 < 0.60"
    code <- paste0(size_code, heterogeneity_code)
    note <- ""
  } else {
    heterogeneity_code <- "L"
    heterogeneity_category <- "Large"
    heterogeneity_rule <- "I2 >= 0.60"
    code <- paste0(size_code, heterogeneity_code)
    note <- ""
  }
  
  list(
    code = code,
    n_studies = n,
    i2 = i2,
    size_code = size_code,
    size_category = size_category,
    size_rule = size_rule,
    heterogeneity_code = heterogeneity_code,
    heterogeneity_category = heterogeneity_category,
    heterogeneity_rule = heterogeneity_rule,
    note = note
  )
}

.format_case_value <- function(case, digits = 3) {
  if (is.null(case)) {
    return("unavailable")
  }
  if (is.na(case$code)) {
    return(paste0("unavailable; K=", case$n_studies, "; I2 unavailable"))
  }
  paste0(
    case$code,
    " (", case$size_category, " size: ", case$size_rule,
    "; ", case$heterogeneity_category, " heterogeneity: ", case$heterogeneity_rule,
    ")"
  )
}

.method_feasible <- function(methods, bias_summary = NULL) {
  if (length(methods) == 0) {
    return(character(0))
  }
  if (is.null(bias_summary) || nrow(bias_summary) == 0 ||
      !all(c("paper_method", "status") %in% names(bias_summary))) {
    return(methods)
  }
  idx <- match(methods, bias_summary$paper_method)
  methods[!is.na(idx) & bias_summary$status[idx] == "ok"]
}

.practical_decision_rule <- function(case, bias_summary = NULL) {
  empty <- list(
    observed_setting = "unavailable",
    primary_methods = character(0),
    alternative_methods = character(0),
    marked_methods = character(0),
    note = "I-squared is unavailable, so no practical decision-rule method was marked."
  )
  
  if (is.null(case) || is.null(case$i2) || length(case$i2) != 1L ||
      !is.finite(case$i2) || is.null(case$n_studies)) {
    return(empty)
  }
  
  if (case$i2 < 0.60) {
    observed_setting <- "I-squared < 0.60"
    primary_methods <- "TESS"
    alternative_methods <- character(0)
  } else if (case$n_studies <= 100L) {
    observed_setting <- "I-squared >= 0.60 and K <= 100"
    primary_methods <- "PSM3"
    alternative_methods <- "TESS"
  } else {
    observed_setting <- "I-squared >= 0.60 and K > 100"
    primary_methods <- c("CALI20", "CALI15")
    alternative_methods <- "TESS"
  }
  
  marked_methods <- .method_feasible(primary_methods, bias_summary)
  note <- ""
  if (length(marked_methods) == 0 && length(alternative_methods) > 0) {
    marked_methods <- .method_feasible(alternative_methods, bias_summary)
    if (length(marked_methods) > 0) {
      note <- paste0(
        "Primary recommendation not feasible in this run; marked alternative: ",
        paste(marked_methods, collapse = ", "), "."
      )
    }
  }
  if (length(marked_methods) == 0) {
    note <- "No recommended or alternative method was feasible in this run."
  }
  
  list(
    observed_setting = observed_setting,
    primary_methods = primary_methods,
    alternative_methods = alternative_methods,
    marked_methods = marked_methods,
    note = note
  )
}

.format_decision_rule_value <- function(decision_rule) {
  if (is.null(decision_rule) || is.null(decision_rule$observed_setting)) {
    return("unavailable")
  }
  
  primary <- if (length(decision_rule$primary_methods) > 0) {
    paste(decision_rule$primary_methods, collapse = " or ")
  } else {
    "none"
  }
  alternative <- if (length(decision_rule$alternative_methods) > 0) {
    paste0("; alternative: ", paste(decision_rule$alternative_methods, collapse = " or "))
  } else {
    ""
  }
  marked <- if (length(decision_rule$marked_methods) > 0) {
    paste0("; marked with ***: ", paste(decision_rule$marked_methods, collapse = ", "))
  } else {
    "; marked with ***: none"
  }
  note <- if (!is.null(decision_rule$note) && nzchar(decision_rule$note)) {
    paste0("; ", decision_rule$note)
  } else {
    ""
  }
  
  paste0(
    decision_rule$observed_setting,
    "; recommended: ", primary,
    alternative,
    marked,
    note
  )
}

.type1_performance_table <- function(case_code = NULL) {
  if (is.null(case_code) || is.na(case_code)) {
    return(data.frame())
  }
  
  path <- .pbias_extdata_file("type1_performance.csv")
  if (!nzchar(path) || !file.exists(path)) {
    return(.type1_performance_fallback(case_code))
  }
  
  tab <- utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  num_cols <- setdiff(names(tab), c("case", "method"))
  for (nm in num_cols) {
    tab[[nm]] <- as.numeric(tab[[nm]])
  }
  tab <- tab[tab$case == case_code, , drop = FALSE]
  if (nrow(tab) == 0) {
    return(.type1_performance_fallback(case_code))
  }
  .rank_performance_table(tab)
}

.rank_performance_table <- function(tab) {
  if (is.null(tab) || nrow(tab) == 0) {
    return(data.frame())
  }
  tab$ba_rank <- as.integer(rank(-tab$balanced_accuracy, ties.method = "min"))
  tab$ldist_rank <- as.integer(rank(-tab$ldist, ties.method = "min"))
  
  # Keep `rank` for backwards compatibility with older code. It remains the
  # Balanced Accuracy rank; display sorting is controlled by `ranking_metric`.
  tab$rank <- tab$ba_rank
  tab <- tab[order(tab$rank, tab$false_positive, tab$method), , drop = FALSE]
  tab[, c("case", "rank", "ba_rank", "ldist_rank", "method", "true_positive",
          "false_positive", "precision", "sensitivity", "f1",
          "balanced_accuracy", "inv_fpr", "ldist")]
}

.make_publication_table <- function(bias_summary, performance_rank = NULL,
                                    sort_by_rank = TRUE, digits = 3,
                                    ranking_metric = "logit_distance",
                                    decision_rule = NULL,
                                    recommendation_marker = "***") {
  ranking_metric <- .match_ranking_metric(ranking_metric)
  pvalue <- mapply(
    .format_result_p,
    bias_summary$publication_bias_p,
    bias_summary$status,
    MoreArgs = list(digits = digits),
    USE.NAMES = FALSE
  )
  
  tab <- data.frame(
    method = bias_summary$paper_method,
    pvalue = pvalue,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
  methods_to_mark <- if (!is.null(decision_rule) &&
                         length(decision_rule$marked_methods) > 0) {
    decision_rule$marked_methods
  } else {
    character(0)
  }
  tab$method_display <- ifelse(
    tab$method %in% methods_to_mark,
    paste0(tab$method, recommendation_marker),
    tab$method
  )
  
  if (!is.null(performance_rank) && nrow(performance_rank) > 0) {
    idx <- match(tab$method, performance_rank$method)
    
    balanced_accuracy <- performance_rank$balanced_accuracy[idx]
    balanced_accuracy_text <- ifelse(
      is.na(balanced_accuracy),
      "Unranked*",
      .format_num(balanced_accuracy, digits)
    )
    
    ldist <- performance_rank$ldist[idx]
    ldist_text <- ifelse(
      is.na(ldist),
      "",
      .format_num(ldist, digits)
    )
    
    false_positive <- performance_rank$false_positive[idx]
    sort_metric_value <- if (identical(ranking_metric, "balanced_accuracy")) {
      balanced_accuracy
    } else {
      ldist
    }
    
    tab <- data.frame(
      Method = tab$method_display,
      `P-value` = tab$pvalue,
      `Balanced Accuracy` = balanced_accuracy_text,
      `Logit Distance`= ldist_text,
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
    
    if (isTRUE(sort_by_rank)) {
      order_key <- ifelse(is.na(sort_metric_value), Inf, -sort_metric_value)
      false_positive_key <- ifelse(is.na(false_positive), Inf, false_positive)
      tab <- tab[order(order_key, false_positive_key, seq_len(nrow(tab))), , drop = FALSE]
    }
  } else {
    tab <- data.frame(
      Method = tab$method_display,
      `P-value` = tab$pvalue,
      `Balanced Accuracy` = "not available",
      `Logit Distance` = "not available",
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }
  
  tab
}

.make_bias_summary <- function(bias_summary) {
  out <- bias_summary[, setdiff(names(bias_summary), "code_method"), drop = FALSE]
  names(out)[names(out) == "publication_bias_p"] <- "p-value"
  row.names(out) <- NULL
  out
}

# Baseline ----------------------------------------------------------------

.fit_baseline_re <- function(dt) {
  mod <- tryCatch(
    metafor::rma(dt$eff, dt$se^2, method = "ML"),
    error = function(e) NULL
  )
  if (is.null(mod)) {
    return(list(
      model = NULL,
      estimates = rbind(
        .make_estimates("b0", note = "Baseline RE model failed."),
        .make_estimates("tau2"),
        .make_estimates("I2")
      )
    ))
  }
  
  est <- rbind(
    .make_estimates("b0", mod$b[[1]], mod$se[[1]], mod$zval[[1]], mod$pval[[1]],
                    mod$ci.lb[[1]], mod$ci.ub[[1]]),
    .make_estimates("tau2", mod$tau2),
    .make_estimates("I2", mod$I2 / 100)
  )
  list(model = mod, estimates = est)
}

# Egger variants -----------------------------------------------------------

.fit_egger_fe <- function(dt) {
  if (length(unique(dt$se)) < 2L) {
    return(.na_result("Egger regression requires varying standard errors.", status = "not_applicable"))
  }
  mod <- tryCatch(
    metafor::rma(dt$eff ~ dt$se, dt$se^2, method = "FE"),
    error = function(e) NULL
  )
  if (is.null(mod)) return(.na_result("FE Egger model failed."))
  
  est <- .make_estimates(
    term = c("b0", "se"),
    estimate = as.numeric(mod$b),
    std_error = mod$se,
    statistic = mod$zval,
    p_value = mod$pval,
    conf_low = mod$ci.lb,
    conf_high = mod$ci.ub
  )
  list(estimates = est, pub_bias_p = est$p_value[est$term == "se"], status = "ok", note = "")
}

.fit_egger_re <- function(dt) {
  if (length(unique(dt$se)) < 2L) {
    return(.na_result("Egger regression requires varying standard errors.", status = "not_applicable"))
  }
  mod <- tryCatch(
    metafor::rma(dt$eff ~ dt$se, dt$se^2, method = "REML"),
    error = function(e) NULL
  )
  if (is.null(mod)) return(.na_result("RE Egger model failed."))
  
  est <- .make_estimates(
    term = c("b0", "se"),
    estimate = as.numeric(mod$b),
    std_error = mod$se,
    statistic = mod$zval,
    p_value = mod$pval,
    conf_low = mod$ci.lb,
    conf_high = mod$ci.ub
  )
  est <- rbind(est, .make_estimates("tau2", mod$tau2))
  list(estimates = est, pub_bias_p = est$p_value[est$term == "se"][1], status = "ok", note = "")
}

.fit_egger_wls <- function(dt) {
  if (length(unique(dt$se)) < 2L) {
    return(.na_result("Egger regression requires varying standard errors.", status = "not_applicable"))
  }
  mod <- tryCatch(
    stats::lm(dt$eff ~ dt$se, weights = 1 / (dt$se^2)),
    error = function(e) NULL
  )
  if (is.null(mod)) return(.na_result("WLS Egger model failed."))
  
  co <- summary(mod)$coefficients
  ci <- tryCatch(stats::confint(mod), error = function(e) matrix(NA_real_, nrow = 2, ncol = 2))
  est <- .make_estimates(
    term = c("b0", "se"),
    estimate = as.numeric(co[, 1]),
    std_error = as.numeric(co[, 2]),
    statistic = as.numeric(co[, 3]),
    p_value = as.numeric(co[, 4]),
    conf_low = as.numeric(ci[, 1]),
    conf_high = as.numeric(ci[, 2])
  )
  list(estimates = est, pub_bias_p = est$p_value[est$term == "se"], status = "ok", note = "")
}

# MAIVE / FATIV ------------------------------------------------------------

.MAIVE_EST <- function(dt) {
  invObs <- 1 / dt$obs
  se2 <- dt$se^2
  fit.se2 <- stats::lm(se2 ~ 1 + invObs)
  if (fit.se2$coefficients[1] < 0) {
    fit.se2 <- stats::lm(se2 ~ 0 + invObs)
  }
  se2fit <- stats::fitted(fit.se2)
  se1fit <- sqrt(se2fit)
  maive.est <- stats::lm(dt$eff ~ 1 + se1fit)
  fatpet.test <- summary(maive.est)$coefficient[2, 4]
  if (summary(maive.est)$coefficient[1, 4] < 0.05) {
    maive.est <- stats::lm(dt$eff ~ 1 + se2fit)
  }
  list(model = maive.est, fatpet_test = fatpet.test)
}

.MAIVE2_EST <- function(dt) {
  invObs <- 1 / dt$obs
  se2 <- dt$se^2
  fit.se2 <- stats::lm(se2 ~ 1 + invObs)
  if (fit.se2$coefficients[1] < 0) {
    fit.se2 <- stats::lm(se2 ~ 0 + invObs)
  }
  se2fit <- stats::fitted(fit.se2)
  se1fit <- sqrt(se2fit)
  maive.est <- stats::lm(dt$eff ~ 1 + se1fit, weights = 1 / se2)
  fatpet.test <- summary(maive.est)$coefficient[2, 4]
  if (summary(maive.est)$coefficient[1, 4] < 0.05) {
    maive.est <- stats::lm(dt$eff ~ 1 + se2fit, weights = 1 / se2)
  }
  list(model = maive.est, fatpet_test = fatpet.test)
}

.fit_maive <- function(dt) {
  if (is.null(dt$obs)) {
    return(.na_result("EGGER4 / MAIVE requires `obs`.", status = "requires_obs"))
  }
  if (length(unique(dt$obs)) < 2L) {
    return(.na_result("MAIVE requires varying sample sizes.", status = "not_applicable"))
  }
  ans <- tryCatch(.MAIVE_EST(dt), error = function(e) NULL)
  if (is.null(ans)) return(.na_result("MAIVE model failed."))
  
  co <- summary(ans$model)$coefficients
  ci <- tryCatch(stats::confint(ans$model), error = function(e) matrix(NA_real_, nrow = 2, ncol = 2))
  est <- .make_estimates(
    term = c("b0", "se"),
    estimate = as.numeric(co[, 1]),
    std_error = as.numeric(co[, 2]),
    statistic = as.numeric(co[, 3]),
    p_value = as.numeric(co[, 4]),
    conf_low = as.numeric(ci[, 1]),
    conf_high = as.numeric(ci[, 2])
  )
  list(estimates = est, pub_bias_p = est$p_value[est$term == "se"], status = "ok", note = "")
}

.fit_fativ <- function(dt) {
  if (is.null(dt$obs)) {
    return(.na_result("EGGER5 / FATIV requires `obs`.", status = "requires_obs"))
  }
  if (length(unique(dt$obs)) < 2L) {
    return(.na_result("FATIV requires varying sample sizes.", status = "not_applicable"))
  }
  ans <- tryCatch(.MAIVE2_EST(dt), error = function(e) NULL)
  if (is.null(ans)) return(.na_result("FATIV model failed."))
  
  co <- summary(ans$model)$coefficients
  ci <- tryCatch(stats::confint(ans$model), error = function(e) matrix(NA_real_, nrow = 2, ncol = 2))
  est <- .make_estimates(
    term = c("b0", "se"),
    estimate = as.numeric(co[, 1]),
    std_error = as.numeric(co[, 2]),
    statistic = as.numeric(co[, 3]),
    p_value = as.numeric(co[, 4]),
    conf_low = as.numeric(ci[, 1]),
    conf_high = as.numeric(ci[, 2])
  )
  list(estimates = est, pub_bias_p = est$p_value[est$term == "se"], status = "ok", note = "")
}

# Selection models ---------------------------------------------------------

.fit_psm3 <- function(dt) {
  psm3 <- tryCatch({
    myRE <- metafor::rma(yi = dt$eff, vi = dt$se^2, method = "REML")
    metafor::selmodel(myRE, type = "stepfun", steps = c(0.025, 1))
  }, error = function(e) NULL)
  if (is.null(psm3)) return(.na_result("3PSM failed or did not converge."))
  
  cv.025 <- stats::qnorm(0.975) * dt$se
  est <- c(psm3$tau2[1], psm3$beta[1], psm3$delta[2])
  se <- c(psm3$se.tau2, psm3$se, psm3$se.delta[2])
  pub.sel.3psm <- mean(
    stats::pnorm(cv.025, est[2], sqrt(est[1] + dt$se^2), lower.tail = FALSE) +
      est[3] * stats::pnorm(cv.025, est[2], sqrt(est[1] + dt$se^2), lower.tail = TRUE)
  )
  out <- .make_estimates(
    term = c("tau2", "b0", "pr.nonsig", "pubSelRate"),
    estimate = c(est, pub.sel.3psm),
    std_error = c(se, NA_real_),
    statistic = c(est / se, NA_real_),
    p_value = c(2 * stats::pnorm(-abs(est / se)), NA_real_),
    conf_low = c(est + stats::qnorm(0.025) * se, NA_real_),
    conf_high = c(est + stats::qnorm(0.975) * se, NA_real_)
  )
  list(estimates = out, pub_bias_p = psm3$LRTp, status = "ok", note = "")
}

.fit_psm4 <- function(dt) {
  psm4 <- tryCatch({
    myRE <- metafor::rma(yi = dt$eff, vi = dt$se^2, method = "REML")
    metafor::selmodel(myRE, type = "stepfun", steps = c(0.025, 0.5, 1))
  }, error = function(e) NULL)
  if (is.null(psm4)) return(.na_result("4PSM failed or did not converge."))
  
  cv.025 <- stats::qnorm(0.975) * dt$se
  est <- c(psm4$tau2[1], psm4$beta[1], psm4$delta[2], psm4$delta[3])
  se <- c(psm4$se.tau2, psm4$se, psm4$se.delta[2], psm4$se.delta[3])
  
  sig.plus <- stats::pnorm(cv.025, est[2], sqrt(est[1] + dt$se^2), lower.tail = FALSE)
  nonsig.plus <- stats::pnorm(0, est[2], sqrt(est[1] + dt$se^2), lower.tail = FALSE) - sig.plus
  minus <- stats::pnorm(0, est[2], sqrt(est[1] + dt$se^2), lower.tail = TRUE)
  pub.sel.4psm <- mean(sig.plus + est[3] * nonsig.plus + est[4] * minus)
  
  out <- .make_estimates(
    term = c("tau2", "b0", "pr.nonsig", "pr.opposite", "pubSelRate"),
    estimate = c(est, pub.sel.4psm),
    std_error = c(se, NA_real_),
    statistic = c(est / se, NA_real_),
    p_value = c(2 * stats::pnorm(-abs(est / se)), NA_real_),
    conf_low = c(est + stats::qnorm(0.025) * se, NA_real_),
    conf_high = c(est + stats::qnorm(0.975) * se, NA_real_)
  )
  list(estimates = out, pub_bias_p = psm4$LRTp, status = "ok", note = "")
}

# AK models ----------------------------------------------------------------

.AK1logLik <- function(para, mydata, z = c("est", "log")) {
  z <- match.arg(z)
  if (any(!is.finite(para)) || para[1] < 0 || para[2] <= 0) {
    return(if (z == "est") 1e10 else rep(NA_real_, nrow(mydata)))
  }
  n <- nrow(mydata)
  tauhat <- para[1]
  betap <- para[2]
  Coeff <- as.matrix(para[3:length(para)])
  if (ncol(mydata) > 3) {
    err <- mydata[, 2] - as.matrix(mydata[, c(4:ncol(mydata))]) %*% Coeff
    esthat <- as.matrix(mydata[, c(4:ncol(mydata))]) %*% Coeff
  } else {
    err <- mydata[, 2] - Coeff
    esthat <- Coeff
  }
  
  se <- mydata[, 3]
  t <- mydata[, 2] / mydata[, 3]
  cutoffs <- c(-1.96, 1.96)
  phat <- (abs(t) < 1.96) * betap + (abs(t) >= 1.96) * 1
  meanbeta <- rep(0, n)
  for (i in seq_len(n)) {
    prob_mid <- (stats::pnorm((cutoffs[2] * se[i] - esthat[i]) / sqrt((tauhat) + se[i]^2)) -
                   stats::pnorm((cutoffs[1] * se[i] - esthat[i]) / sqrt((tauhat) + se[i]^2)))
    prob_ex <- 1 - prob_mid
    meanbeta[i] <- betap * prob_mid + 1 * prob_ex
  }
  logL <- stats::dnorm(err, 0, sqrt(se^2 + tauhat), log = TRUE) + log(phat) - log(meanbeta)
  LLH <- -sum(logL)
  if (tauhat < 0 || betap < 0) {
    LLH <- 1e10
  }
  if (z == "est") LLH else logL
}

.AK2logLik <- function(para, mydata, z = c("est", "log")) {
  z <- match.arg(z)
  if (any(!is.finite(para)) || para[1] < 0 || any(para[2:4] <= 0)) {
    return(if (z == "est") 1e10 else rep(NA_real_, nrow(mydata)))
  }
  n <- nrow(mydata)
  tauhat <- para[1]
  beta1 <- para[2]
  beta2 <- para[3]
  beta3 <- para[4]
  Coeff <- as.matrix(para[5:length(para)])
  if (ncol(mydata) > 3) {
    err <- mydata[, 2] - as.matrix(mydata[, c(4:ncol(mydata))]) %*% Coeff
    esthat <- as.matrix(mydata[, c(4:ncol(mydata))]) %*% Coeff
  } else {
    err <- mydata[, 2] - Coeff
    esthat <- Coeff
  }
  
  se <- mydata[, 3]
  t <- mydata[, 2] / mydata[, 3]
  cutoffs <- c(-1.96, 0, 1.96)
  phat <- (t <= -1.96) * beta1 + (t > -1.96 & t <= 0) * beta2 + (0 < t & t < 1.96) * beta3 + (t >= 1.96) * 1
  meanbeta <- rep(0, n)
  for (i in seq_len(n)) {
    prob_vlow <- stats::pnorm((cutoffs[1] * se[i] - esthat[i]) / sqrt((tauhat) + se[i]^2))
    prob_low <- (stats::pnorm((cutoffs[2] * se[i] - esthat[i]) / sqrt((tauhat) + se[i]^2)) -
                   stats::pnorm((cutoffs[1] * se[i] - esthat[i]) / sqrt((tauhat) + se[i]^2)))
    prob_upper <- (stats::pnorm((cutoffs[3] * se[i] - esthat[i]) / sqrt((tauhat) + se[i]^2)) -
                     stats::pnorm((cutoffs[2] * se[i] - esthat[i]) / sqrt((tauhat) + se[i]^2)))
    prob_vupper <- 1 - prob_vlow - prob_low - prob_upper
    meanbeta[i] <- beta1 * prob_vlow + beta2 * prob_low + beta3 * prob_upper + 1 * prob_vupper
  }
  
  logL <- stats::dnorm(err, 0, sqrt(se^2 + tauhat), log = TRUE) + log(phat) - log(meanbeta)
  LLH <- -sum(logL)
  if (tauhat < 0 || beta1 < 0 || beta2 < 0 || beta3 < 0) {
    LLH <- 1e10
  }
  if (z == "est") LLH else logL
}

.ak_likelihood_ratio <- function(loglik_alt, loglik_null, df) {
  if (length(loglik_alt) != 1L || length(loglik_null) != 1L ||
      !is.finite(loglik_alt) || !is.finite(loglik_null)) {
    return(list(statistic = NA_real_, df = df, p_value = NA_real_,
                status = "failed", note = "AK likelihood comparison is unavailable."))
  }
  statistic <- 2 * (loglik_alt - loglik_null)
  tolerance <- 1e-7 * (1 + abs(loglik_null))
  if (statistic < -tolerance) {
    return(list(statistic = statistic, df = df, p_value = NA_real_, status = "failed",
                note = "AK optimization returned a lower likelihood than the nested no-selection model."))
  }
  statistic <- max(0, statistic)
  list(statistic = statistic, df = df,
       p_value = stats::pchisq(statistic, df, lower.tail = FALSE),
       loglik_alt = loglik_alt, loglik_null = loglik_null, status = "ok", note = "")
}

.fit_ak1 <- function(dt) {
  if (nrow(dt) <= 3L || length(unique(abs(dt$eff / dt$se) >= 1.96)) < 2L) {
    return(.na_result("AK1 requires more than three studies and both significant and nonsignificant effects.",
                      status = "not_applicable"))
  }
  AKdata <- as.data.frame(cbind(id = as.numeric(dt$StdID), effect = dt$eff, se = dt$se, constant = 1))
  InitialValue <- as.numeric(mean(AKdata$effect))
  t2 <- mean(AKdata$se^2) / 4
  fn <- function(par) .AK1logLik(par, AKdata, "est")
  Result <- tryCatch(
    stats::nlminb(objective = fn,
           start = c(t2, 1, InitialValue),
           lower = c(0, 0.01, rep(-Inf, length(InitialValue))),
           upper = c(Inf, Inf, rep(Inf, length(InitialValue))),
           control = list(iter.max = 1000, abs.tol = 10^(-20), eval.max = 1000)),
    error = function(e) NULL
  )
  if (is.null(Result) || !isTRUE(Result$convergence == 0) ||
      any(!is.finite(Result$par)) || !is.finite(Result$objective)) {
    return(.na_result("AK1 failed or did not converge."))
  }
  
  se_vec <- tryCatch(
    sqrt(diag(MASS::ginv(numDeriv::hessian(fn, Result$par), tol = 10^(-30)))),
    error = function(e) rep(NA_real_, length(Result$par))
  )
  estcoef <- as.numeric(Result$par)
  if (any(!is.finite(se_vec))) {
    return(.na_result("AK1 Hessian inversion failed."))
  }
  crit <- stats::qt(0.975, df = (nrow(AKdata) - length(estcoef)))
  b0_est <- estcoef[3]
  b0_se <- se_vec[3]
  rho1_est <- estcoef[2]
  rho1_se <- se_vec[2]
  tau2_est <- estcoef[1]
  tau2_se <- se_vec[1]
  # The objective is a NEGATIVE log-likelihood. Store a log-likelihood here,
  # matching import/0-EstimatorsFULL.R before comparing the two models.
  AK1LLK <- -.AK1logLik(Result$par, AKdata, "est")
  
  re_mod <- tryCatch(metafor::rma(dt$eff, dt$se^2, method = "ML"), error = function(e) NULL)
  RE_LLK <- if (is.null(re_mod)) NA_real_ else as.numeric(stats::logLik(re_mod, REML = FALSE))
  likelihood_test <- .ak_likelihood_ratio(AK1LLK, RE_LLK, df = 1)
  if (likelihood_test$status != "ok") return(.na_result(likelihood_test$note))
  cv.025 <- stats::qnorm(0.975) * dt$se
  if (!is.na(RE_LLK) && !is.na(AK1LLK)) {
    pLRT <- likelihood_test$p_value
    sig.plus <- stats::pnorm(cv.025, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = FALSE)
    nonsig.plus <- stats::pnorm(0, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = FALSE) - sig.plus
    sig.min <- stats::pnorm(-cv.025, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = TRUE)
    nonsig.min <- stats::pnorm(0, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = TRUE) - sig.min
    pub.sel <- mean(sig.plus + rho1_est * (nonsig.plus + nonsig.min) + sig.min)
  } else {
    pLRT <- NA_real_
    pub.sel <- NA_real_
  }
  
  est <- rbind(
    .make_estimates("b0", b0_est, b0_se, b0_est / b0_se,
                    2 * stats::pt(-abs(b0_est / b0_se), df = nrow(AKdata) - length(estcoef)),
                    b0_est - crit * b0_se, b0_est + crit * b0_se),
    .make_estimates("rho1", rho1_est, rho1_se),
    .make_estimates("tau2", tau2_est, tau2_se),
    .make_estimates("pubSelRate", pub.sel)
  )
  list(estimates = est, pub_bias_p = pLRT, status = "ok", note = "", test = likelihood_test)
}

.fit_ak2 <- function(dt) {
  z <- dt$eff / dt$se
  region_counts <- c(sum(z <= -1.96), sum(-1.96 < z & z <= 0),
                     sum(0 < z & z < 1.96), sum(z >= 1.96))
  if (nrow(dt) <= 5L || any(region_counts == 0L)) {
    return(.na_result("AK2 requires more than five studies and observations in all four selection intervals.",
                      status = "not_applicable"))
  }
  AKdata <- as.data.frame(cbind(id = as.numeric(dt$StdID), effect = dt$eff, se = dt$se, constant = 1))
  InitialValue <- as.numeric(mean(AKdata$effect))
  t2 <- mean(AKdata$se^2) / 4
  fn <- function(par) .AK2logLik(par, AKdata, "est")
  Result <- tryCatch(
    stats::nlminb(objective = fn,
           start = c(t2, 1, 1, 1, InitialValue),
           lower = c(0, 0.01, 0.01, 0.01, rep(-Inf, length(InitialValue))),
           upper = c(Inf, Inf, Inf, Inf, rep(Inf, length(InitialValue))),
           control = list(iter.max = 1000, abs.tol = 10^(-20), eval.max = 1000)),
    error = function(e) NULL
  )
  if (is.null(Result) || !isTRUE(Result$convergence == 0) ||
      any(!is.finite(Result$par)) || !is.finite(Result$objective)) {
    return(.na_result("AK2 failed or did not converge."))
  }
  
  se_vec <- tryCatch(
    sqrt(diag(MASS::ginv(numDeriv::hessian(fn, Result$par), tol = 10^(-30)))),
    error = function(e) rep(NA_real_, length(Result$par))
  )
  estcoef <- as.numeric(Result$par)
  if (any(!is.finite(se_vec))) {
    return(.na_result("AK2 Hessian inversion failed."))
  }
  
  crit <- stats::qt(0.975, df = (nrow(AKdata) - length(estcoef)))
  tau2_est <- estcoef[1]; tau2_se <- se_vec[1]
  rho1_est <- estcoef[2]; rho1_se <- se_vec[2]
  rho2_est <- estcoef[3]; rho2_se <- se_vec[3]
  rho3_est <- estcoef[4]; rho3_se <- se_vec[4]
  b0_est <- estcoef[5]; b0_se <- se_vec[5]
  AK2LLK <- -.AK2logLik(Result$par, AKdata, "est")
  
  re_mod <- tryCatch(metafor::rma(dt$eff, dt$se^2, method = "ML"), error = function(e) NULL)
  RE_LLK <- if (is.null(re_mod)) NA_real_ else as.numeric(stats::logLik(re_mod, REML = FALSE))
  # Three free publication weights are fixed at one under no selection.
  likelihood_test <- .ak_likelihood_ratio(AK2LLK, RE_LLK, df = 3)
  if (likelihood_test$status != "ok") return(.na_result(likelihood_test$note))
  cv.025 <- stats::qnorm(0.975) * dt$se
  if (!is.na(RE_LLK) && !is.na(AK2LLK)) {
    pLRT <- likelihood_test$p_value
    sig.plus <- stats::pnorm(cv.025, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = FALSE)
    nonsig.plus <- stats::pnorm(0, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = FALSE) - sig.plus
    sig.min <- stats::pnorm(-cv.025, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = TRUE)
    nonsig.min <- stats::pnorm(0, b0_est, sqrt(tau2_est + dt$se^2), lower.tail = TRUE) - sig.min
    pub.sel <- mean(sig.plus + rho3_est * nonsig.plus + rho2_est * nonsig.min + rho1_est * sig.min)
  } else {
    pLRT <- NA_real_
    pub.sel <- NA_real_
  }
  
  est <- rbind(
    .make_estimates("b0", b0_est, b0_se, b0_est / b0_se,
                    2 * stats::pt(-abs(b0_est / b0_se), df = nrow(AKdata) - length(estcoef)),
                    b0_est - crit * b0_se, b0_est + crit * b0_se),
    .make_estimates("rho1", rho1_est, rho1_se),
    .make_estimates("rho2", rho2_est, rho2_se),
    .make_estimates("rho3", rho3_est, rho3_se),
    .make_estimates("tau2", tau2_est, tau2_se),
    .make_estimates("pubSelRate", pub.sel)
  )
  list(estimates = est, pub_bias_p = pLRT, status = "ok", note = "", test = likelihood_test)
}

# EK, TES, PSST/TESS, BEGG, p-uniform -------------------------------------

.fit_ek <- function(dt, tb = 1.96, ts = 1.96) {
  d <- dt$eff
  v <- dt$se^2
  se <- sqrt(v)
  m <- length(v)
  out <- tryCatch({
    FP1 <- summary(stats::lm(d ~ se, weights = 1 / v))
    if (FP1$coefficient[1, 4] > 0.05) {
      alpha1 <- as.numeric(FP1$coefficient[1, 1])
      Q <- sum((as.numeric(FP1$residuals) / se)^2)
    } else {
      FP2 <- summary(stats::lm(d ~ v, weights = 1 / v))
      alpha1 <- as.numeric(FP2$coefficient[1, 1])
      Q <- sum((as.numeric(FP2$residuals) / se)^2)
    }
    wi <- 1 / v
    sig_eta2 <- max(0, m * ((Q / (m - 2)) - 1) / sum(wi))
    a <- (((alpha1^2) - tb * tb * sig_eta2) / ((tb + ts) * alpha1)) * (alpha1 > (tb * sqrt(sig_eta2)))
    g <- (se - a) * (se >= a)
    reg <- stats::lm(d ~ g, weights = 1 / v)
    EKreg <- summary(reg)$coefficient
    EKConf <- stats::confint(reg)
    list(EKreg = EKreg, EKConf = EKConf)
  }, error = function(e) NULL)
  
  if (is.null(out) || any(is.na(out$EKConf))) return(.na_result("EK failed."))
  
  est <- .make_estimates(
    term = c("b0", "g"),
    estimate = as.numeric(out$EKreg[, 1]),
    std_error = as.numeric(out$EKreg[, 2]),
    statistic = as.numeric(out$EKreg[, 3]),
    p_value = as.numeric(out$EKreg[, 4]),
    conf_low = as.numeric(out$EKConf[, 1]),
    conf_high = as.numeric(out$EKConf[, 2])
  )
  list(estimates = est, pub_bias_p = est$p_value[est$term == "g"], status = "ok", note = "")
}

.fit_tes <- function(dt, alpha = 0.025, side = "right") {
  out <- tryCatch({
    est.fe <- metafor::rma(yi = dt$eff, sei = dt$se, method = "FE")$b[1]
    if (side == "right") {
      pow <- stats::pnorm(stats::qnorm(alpha, lower.tail = FALSE, sd = dt$se), mean = est.fe,
                          sd = dt$se, lower.tail = FALSE)
      O <- sum(stats::pnorm(dt$eff / dt$se, lower.tail = FALSE) < alpha)
    } else {
      pow <- stats::pnorm(stats::qnorm(alpha, sd = dt$se), mean = est.fe, sd = dt$se)
      O <- sum(stats::pnorm(dt$eff / dt$se) < alpha)
    }
    E <- sum(pow)
    n <- length(dt$eff)
    A <- (O - E)^2 / E + (O - E)^2 / (n - E)
    pval.tes <- stats::pchisq(A, 1, lower.tail = FALSE)
    pval.tes <- ifelse(pval.tes < 0.5, pval.tes * 2, (1 - pval.tes) * 2)
    list(A = A, pval.tes = pval.tes, O = O, E = E, n = n)
  }, error = function(e) NULL)
  
  if (is.null(out)) return(.na_result("TES failed."))
  list(estimates = NULL, pub_bias_p = out$pval.tes, status = "ok", note = "")
}

.fit_psst_tess <- function(dt) {
  out <- tryCatch({
    k <- length(dt$eff)
    t <- dt$eff / dt$se
    Precision <- 1 / dt$se
    MA <- metafor::rma(yi = dt$eff, sei = dt$se, method = "DL")
    HetVar <- MA$tau2
    reg <- stats::lm(t ~ 0 + Precision)
    UWLS <- as.numeric(reg$coefficients)
    zz <- ((1.96 * dt$se - UWLS) / (dt$se^2 + HetVar)^0.5)
    Esigtot <- sum(1 - stats::pnorm(zz))
    SS <- (t > 1.96) * 1
    SStot <- sum(SS)
    Pss <- SStot / k
    ESS <- (SStot - Esigtot) / k
    Pe <- Esigtot / k
    PSST <- (Pss - Pe) / (Pe * (1 - Pe) / k)^0.5
    TESS <- (ESS - 0.05) / (0.0475 / k)^0.5
    list(
      psst_p = (1 - stats::pnorm(PSST)),
      tess_p = (1 - stats::pnorm(TESS)),
      psst_z = PSST,
      tess_z = TESS
    )
  }, error = function(e) NULL)
  
  if (is.null(out)) {
    return(list(psst_p = NA_real_, tess_p = NA_real_, status = "failed", note = "PSST/TESS failed."))
  }
  list(psst_p = out$psst_p, tess_p = out$tess_p, status = "ok", note = "")
}

.fit_begg <- function(dt) {
  out <- tryCatch(
    metafor::ranktest(dt$eff, sei = dt$se, exact = FALSE)$pval,
    error = function(e) NA_real_
  )
  list(pub_bias_p = as.numeric(out), status = ifelse(is.na(out), "failed", "ok"), note = ifelse(is.na(out), "Begg test failed.", ""))
}

.fit_puniform <- function(dt) {
  PuniTest <- tryCatch(
    puniform::puniform(yi = dt$eff, vi = dt$se^2, side = "right"),
    error = function(e) NULL
  )
  if (is.null(PuniTest)) return(.na_result("p-uniform failed."))
  est <- .make_estimates(
    term = "b0",
    estimate = as.numeric(PuniTest$est),
    std_error = NA_real_,
    statistic = NA_real_,
    p_value = as.numeric(PuniTest$pval.0),
    conf_low = as.numeric(PuniTest$ci.lb),
    conf_high = as.numeric(PuniTest$ci.ub)
  )
  list(estimates = est, pub_bias_p = as.numeric(PuniTest$pval.pb), status = "ok", note = "")
}

# Skewness ----------------------------------------------------------------

.fit_skew <- function(dt, reMA_model) {
  if (length(unique(dt$se)) < 2L) {
    return(list(skew_p = NA_real_, combined_p = NA_real_, status = "not_applicable",
                note = "Skewness regression requires varying standard errors."))
  }
  if (is.null(reMA_model)) {
    return(list(skew_p = NA_real_, combined_p = NA_real_, status = "failed", note = "Baseline RE model unavailable."))
  }
  out <- tryCatch({
    tau2 <- reMA_model$tau2
    if (!is.finite(tau2)) stop("tau2 is not finite")
    std.y <- dt$eff / sqrt(dt$se^2 + tau2)
    std.x <- 1 / sqrt(dt$se^2 + tau2)
    skew.reg <- stats::lm(std.y ~ std.x)
    std.dev <- as.numeric(summary(skew.reg)$residuals)
    cm2 <- stats::var(std.dev)
    cm3 <- mean((std.dev - mean(std.dev))^3)
    cm4 <- mean((std.dev - mean(std.dev))^4)
    cm5 <- mean((std.dev - mean(std.dev))^5)
    cm6 <- mean((std.dev - mean(std.dev))^6)
    skewness <- cm3 / (cm2^(1.5))
    var0.skew <- 6
    skewness.pval <- 2 * (1 - stats::pnorm(sqrt(length(dt$eff) / var0.skew) * abs(skewness)))
    reg.coef <- summary(skew.reg)$coef
    reg.pval <- reg.coef["(Intercept)", "Pr(>|t|)"]
    combined.pval <- 1 - (1 - min(c(reg.pval, skewness.pval)))^2
    list(skewness.pval = skewness.pval, combined.pval = combined.pval)
  }, error = function(e) NULL)
  
  if (is.null(out)) {
    return(list(skew_p = NA_real_, combined_p = NA_real_, status = "failed", note = "Skewness tests failed."))
  }
  list(skew_p = out$skewness.pval, combined_p = out$combined.pval, status = "ok", note = "")
}

# Calipers ----------------------------------------------------------------

.fit_calipers <- function(dt, alpha = 0.05) {
  zcrit <- stats::qnorm(1 - alpha / 2)
  abtstat <- abs(dt$eff / dt$se)
  windows <- c(0.05, 0.10, 0.15, 0.20)
  # Reproduce the simulation's literal rounded endpoints at the default level.
  # In particular CALI05 uses (1.86, 1.96) and (1.96, 2.06), not +/-0.098.
  if (alpha == 0.05) {
    zcrit <- 1.96
    lower <- c(1.86, 1.76, 1.66, 1.56)
    upper <- c(2.06, 2.16, 2.26, 2.36)
  } else {
    lower <- zcrit * (1 - windows)
    upper <- zcrit * (1 + windows)
  }
  code_methods <- c("Caliper05", "Caliper10", "Caliper15", "Caliper20")
  notes <- character(length(windows))
  pvals <- numeric(length(windows))
  status <- character(length(windows))
  
  for (i in seq_along(windows)) {
    over <- sum(zcrit < abtstat & abtstat < upper[i])
    under <- sum(lower[i] < abtstat & abtstat < zcrit)
    total <- over + under
    if (total < 5) {
      pvals[i] <- NA_real_
      status[i] <- "not_applicable"
      notes[i] <- "Fewer than 5 studies in the combined caliper interval."
    } else {
      pvals[i] <- stats::binom.test(c(over, under), alternative = "greater")$p.value
      status[i] <- "ok"
      notes[i] <- paste0("Counts: over=", over, ", under=", under)
    }
  }
  
  list(summary = data.frame(
    code_method = code_methods,
    publication_bias_p = pvals,
    status = status,
    note = notes,
    stringsAsFactors = FALSE
  ))
}
