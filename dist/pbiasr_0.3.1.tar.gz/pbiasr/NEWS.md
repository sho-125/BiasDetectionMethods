# pbiasr 0.3.1

- Closest lookup now defaults to Extended / all QRP / All conditions / pooled censoring levels.
- The biased-only universe includes QRP-only conditions (censoring or QRP defines bias), consistently for matching and performance.
- Matched mean estimated tau-squared is shown alongside mean tau. These are distinct averages.
- Added a sorted method summary: equal-weight mean Balanced Accuracy across matched groups, per-metric coverage, and applicability. Complete averages require a valid value in every match; detailed match results are retained.

# pbiasr 0.3.0

- Added `pbias_closest(k, tau)` to find and present neighbouring simulation conditions and performance of all 21 methods.
- Individual conditions are the default: mean estimated tau is computed across replications within each condition. Neighbouring matches stay separate. Optional pooling across publication-bias severity is explicit.
- Bundled summaries of the 864-condition Extended design and 432-condition Original subset, with data provenance, applicability and missing control metrics retained.
- Retained the 0.2.9 AK likelihood-ratio, coefficient p-value, TES, caliper and applicability corrections.

# pbiasr 0.2.9

- Corrected AK1/AK2 likelihood-ratio signs and degrees of freedom, coefficient tail probabilities, Hessian standard errors and invalid-fit handling.
- Matched TES and caliper defaults to the supplied simulation implementation.
- Reported unavailable regression slopes and invalid p-values explicitly.
